<?php
/**
 * 这个是调用Sdk里检查用户登陆SessionId是否有效的DEMO
 * 
 */
require_once 'Sdk.php';

$Sdk = new Sdk();

//用户的91Uin
$Uin = "155697594";

//用户登陆SessionId
$SessionId = "39a973600853e9e9970c38f6c6779bdd";

$Res = $Sdk->check_user_login($Uin,$SessionId);

print_r($Res);

?>