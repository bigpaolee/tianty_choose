﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NetDragon.MobileCenter.DemoAP
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnGenSignAct1_Click(object sender, EventArgs e)
        {
            txtSign1.Text = String.Format("{0}{1}{2}{3}", txtProductId.Text, 1, txtCooOrderSerial.Text, txtAppKey.Text).HashToMD5Hex();
        }

        protected void btnCallAct1_Click(object sender, EventArgs e)
        {
            string url = ddlUrl.SelectedValue;
            url += "?AppId=" + txtProductId.Text;
            url += "&Act=1";
            url += "&CooOrderSerial=" + txtCooOrderSerial.Text;
            url += "&Sign=" + txtSign1.Text;

            txtResult1.Text = HttpPostManager.GetStringData(url);
        }

        protected void btnGenSignAct2_Click(object sender, EventArgs e)
        {
            txtSign2.Text = String.Format("{0}{1}{2}{3}{4}{5}", txtProductId.Text, 2, txtUin.Text, ddlDynaType.SelectedValue, txtDynaInfo.Text, txtAppKey.Text).HashToMD5Hex();
        }

        protected void btnCallAct2_Click(object sender, EventArgs e)
        {
            string url = ddlUrl.SelectedValue;
            url += "?AppId=" + txtProductId.Text;
            url += "&Act=2";
            url += "&Uin=" + txtUin.Text;
            url += "&Type=" + ddlDynaType.SelectedValue;
            url += "&DynaInfo=" + txtDynaInfo.Text.UrlEncode();
            url += "&Sign=" + txtSign2.Text;

            txtResult2.Text = HttpPostManager.GetStringData(url);
        }

        protected void btnGenSignAct3_Click(object sender, EventArgs e)
        {
            txtSign3.Text = String.Format("{0}{1}{2}{3}{4}", txtProductId.Text, 3, txtPageNumber3.Text, txtPageSize3.Text, txtAppKey.Text).HashToMD5Hex();
        }

        protected void btnCallAct3_Click(object sender, EventArgs e)
        {
            string url = ddlUrl.SelectedValue;
            url += "?AppId=" + txtProductId.Text;
            url += "&Act=3";
            url += "&Uin=" + txtUin.Text;
            url += "&Sign=" + txtSign3.Text;
            url += "&PageNo=" + txtPageNumber3.Text;
            url += "&PageSize=" + txtPageSize3.Text;

            txtResult3.Text = HttpPostManager.GetStringData(url);
        }

        protected void btnGenSignAct4_Click(object sender, EventArgs e)
        {
            txtSign4.Text = String.Format("{0}{1}{2}{3}{4}", txtProductId.Text, 4, txtUin.Text, txtSessionID4.Text, txtAppKey.Text).HashToMD5Hex();
        }

        protected void btnCallAct4_Click(object sender, EventArgs e)
        {
            string url = ddlUrl.SelectedValue;
            url += "?AppId=" + txtProductId.Text;
            url += "&Act=4";
            url += "&Uin=" + txtUin.Text;
            url += "&Sign=" + txtSign4.Text;
            url += "&SessionID=" + txtSessionID4.Text;

            txtResult4.Text = HttpPostManager.GetStringData(url);
        }

        protected void btnGenSignAct5_Click(object sender, EventArgs e)
        {
            txtSign5.Text = String.Format("{0}{1}{2}{3}{4}{5}{6}", txtProductId.Text, 5, txtUin.Text, txtSessionID5.Text, txtPageNumber5.Text, txtPageSize5.Text, txtAppKey.Text).HashToMD5Hex();
        }

        protected void btnCallAct5_Click(object sender, EventArgs e)
        {
            string url = ddlUrl.SelectedValue;
            url += "?AppId=" + txtProductId.Text;
            url += "&Act=5";
            url += "&Uin=" + txtUin.Text;
            url += "&Sign=" + txtSign5.Text;
            url += "&PageNo=" + txtPageNumber5.Text;
            url += "&PageSize=" + txtPageSize5.Text;
            url += "&SessionID=" + txtSessionID5.Text;

            txtResult5.Text = HttpPostManager.GetStringData(url);
        }

        protected void btnGenSignAct6_Click(object sender, EventArgs e)
        {
            txtSign6.Text = String.Format("{0}{1}{2}{3}{4}{5}{6}", txtProductId.Text, 6, txtUin.Text, txtSessionID6.Text, txtPageNumber6.Text, txtPageSize6.Text, txtAppKey.Text).HashToMD5Hex();
        }

        protected void btnCallAct6_Click(object sender, EventArgs e)
        {
            string url = ddlUrl.SelectedValue;
            url += "?AppId=" + txtProductId.Text;
            url += "&Act=6";
            url += "&Uin=" + txtUin.Text;
            url += "&Sign=" + txtSign6.Text;
            url += "&PageNo=" + txtPageNumber6.Text;
            url += "&PageSize=" + txtPageSize6.Text;
            url += "&SessionID=" + txtSessionID6.Text;

            txtResult6.Text = HttpPostManager.GetStringData(url);
        }

        protected void dpAPIList_SelectedIndexChanged(object sender, EventArgs e)
        {
            var id = dpAPIList.SelectedItem.Value;
            var panel = FindControl(id) as Panel;
            if (panel != null)
            {
                panel.Visible = true;
                HideOtherPanel(id);
            }
        }

        private void HideOtherPanel(String excludePanelID)
        {
            HideSubControls(Controls, excludePanelID);
        }

        private void HideSubControls(ControlCollection controls, String excludePanelID)
        {
            if (controls != null && controls.Count > 0)
            {
                foreach (Control item in controls)
                {
                    var p = item as Panel;
                    if (p != null && p.ID.IndexOf("Panel") >= 0 && p.ID != excludePanelID)
                    {
                        p.Visible = false;
                    }
                    HideSubControls(item.Controls, excludePanelID);
                }
            }
        }
    }
}