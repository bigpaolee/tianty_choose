<?php
/**
 * 这个是调用Sdk里查询支付购买结果的DEMO
 * 
 */
require_once 'Sdk.php';

$sdk = new Sdk();

//商户订单号
$CooOrderSerial = "bc967008997b4cdbb60b36f1a27c58d9";//"bc967008997b4cdbb60b36f1a27c58d9"

$Res = $sdk->query_pay_result($CooOrderSerial);

print_r($Res);

?>